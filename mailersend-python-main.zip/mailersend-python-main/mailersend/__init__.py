"""
MailerSend Official Python DSK
@maintainer: Igor Hrček (igor at mailerlite dot com)
"""

__version_info__ = ("0", "5", "6")
__version__ = ".".join(__version_info__)
